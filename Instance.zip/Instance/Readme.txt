Set I contains 64 instances of multiple hospital.
Set II includes 9 instances of one hospital.
Set III is the real-world instance.
All the instances are in the format of：
The total number of medical teams.
The total number of medical staff.
The total number of hospitals.
The total number of wards.
The number of medical staff of each medical team.
The number of wards of each hospital.
The required number of doctors in each ward.
The required number of nurses in each ward.
The group number of each ward.
The urgency level of each ward.
The fitness level of each skill to each ward.
